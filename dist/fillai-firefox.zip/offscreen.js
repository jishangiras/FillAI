import"./assets/modulepreload-polyfill-B5Qt9EMX.js";import{r as n}from"./assets/ai-core-BRjqJJmj.js";import{e as o}from"./assets/browser-CrYFXM8W.js";o.onMessage(async r=>{const e=r;if(e.type==="FILLAI_OFFSCREEN_INFER")return n(e.payload)});
//# sourceMappingURL=offscreen.js.map
