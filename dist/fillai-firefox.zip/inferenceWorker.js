import{r as a}from"./assets/ai-core-BRjqJJmj.js";self.onmessage=async r=>{try{const s=await a(r.data.request,e=>{self.postMessage({id:r.data.id,type:"progress",message:e})});self.postMessage({id:r.data.id,type:"result",result:s})}catch(s){self.postMessage({id:r.data.id,type:"error",error:s instanceof Error?s.message:String(s)})}};
//# sourceMappingURL=inferenceWorker.js.map
